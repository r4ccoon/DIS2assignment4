package toolkit;
public class Vector2 {
	int x;
	int y;
	
	public Vector2(int vx, int vy){
		x = vx;
		y = vy;
	}
	
	public Vector2(){
		
	}
	
	public int getX() {
		return x;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setY(int y) {
		this.y = y;
	}
}
