package toolkit;

public interface WindowEventHandler {
	public void OnCloseWindow(Window win );
}
