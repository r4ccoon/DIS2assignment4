package toolkit;

public interface Listener {
	public void OnClick(Widget w, EventArgs e);
}
