package toolkit;

public interface ButtonEventHandler {

    void OnClick(Button button, EventArgs e);

}