// todo: remove hardcoded values

public class Constants {
    static final int title_bar_height = 20;
    static final int close_button_height = 10;
    static final int close_button_width = 10 ;
    static final int minimise_button_width = 10 ;
    static final int minimise_button_height = 10 ;
    static final int spacing_between_buttons = 5 ;
    static final int to_get_midpoint = 2 ;
    static final int xPositionTittleName = 40 ;
    public static final int OS_title_bar_height = 25;
    
    public static final int width_minimized = 100 ;
    public static final int height_minimized = 40 ;
    
} 
