
public class SizeType {
	public static final int width = 0;
	public static final int height = 1; 
}
