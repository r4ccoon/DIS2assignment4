
public interface CloseButtonHandler {
	public void OnClickCloseButton(Widget w, EventArgs e);
}
